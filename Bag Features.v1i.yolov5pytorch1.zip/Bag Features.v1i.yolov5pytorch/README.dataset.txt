# Bag Features > 2024-07-22 6:45am
https://universe.roboflow.com/objdetection-xqsus/bag-features

Provided by a Roboflow user
License: CC BY 4.0

